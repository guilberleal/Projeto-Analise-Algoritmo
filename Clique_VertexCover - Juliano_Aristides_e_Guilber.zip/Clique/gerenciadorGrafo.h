#include <stdio.h>
#include <stdlib.h>
#include <math.h>

typedef struct Grafo{
	int size;
	int *keys; //Armazena a solucao
	int **mat3D;	
}grafo;

grafo *criaGrafoDesconexo(int qtdVertices);
grafo *carregarGrafo(char *nomeArq);
int salvarGrafo(grafo *g, char*nomeArq);
void showGrafo(grafo *g);
grafo *grafoComplemento(grafo *g);
int **getPossibilidades(int qtdVertices);
void showTabela(int **tabela, int sizeCol);
int ehSolucao(grafo *g, int *arranjo);
grafo *resolveVertex(grafo *g);
grafo *resolveClique(grafo *clique, int k);
void showSolucao(grafo *g);

int *criaInstanciaToSolucao(int qtdNOs);
void preencherInstancia(int *ins, int size);
