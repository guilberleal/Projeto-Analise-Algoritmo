


void bubble_sort(int *vet);
void QuickSort(int *vet,int begin,int end);
void select_sort(int *vet);
void Merge(int *vet,int begin, int middle, int end);
void Sort(int *vet,int begin, int end);
void read_archive(int *vet, char *name);
void heap_sort(int *vet, int n);
void QuickSort_rand(int *vet,int begin,int end);
void test(int *vet, char *name_a);
void clear_vet(int *vet);