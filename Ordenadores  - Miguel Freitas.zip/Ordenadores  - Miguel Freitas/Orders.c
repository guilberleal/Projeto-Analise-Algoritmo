#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>
#include "Orders.h"

/* 
    Miguel Freitas - CCOMP
    Turma PAA 2019/2
    Trabalho Ordenadores e complexidade assintótica

*/

int SIZE = 10000000;

int main(int argc, char const *argv[])
{
	int *vet;
	char name_a[30];
	

	FILE *arq;

	arq = fopen("input.txt","r");

	if(arq == NULL){
		printf("Fail, could not open file.\n");
		return 0;
	}
    
    
	while( !feof(arq) ){
		fscanf(arq,"%s", name_a);


       
        vet = (int*)malloc( sizeof(int) * SIZE);

       
        printf("\t\t\tArchive: %s\n\n", name_a);
        test(vet,name_a);
        
        SIZE = SIZE * 10;       
	}
    
        

	return 0;	
}

void test(int *vet, char *name_a){
	clock_t start_time, end_time;
	double time_cost;

	
	read_archive(vet, name_a);
    
	printf("antes: %d %d\n",vet[0],vet[SIZE-1]);
	start_time = clock();
	bubble_sort(vet);
	end_time = clock();
	time_cost =(double)(end_time - start_time)/CLOCKS_PER_SEC;
	printf( "Execution time was %lfs\n",time_cost );
	printf("%d %d // bubble: ok\n\n",vet[0],vet[SIZE-1]);
	

	read_archive(vet, name_a);
	printf("antes: %d %d\n",vet[0],vet[SIZE-1]);
	start_time = clock();
	QuickSort(vet, 0, SIZE-1);
	end_time = clock();
	time_cost =(double)(end_time - start_time)/CLOCKS_PER_SEC;
	printf( "Execution time was %lfs\n",time_cost );
	printf("%d %d // Quick: ok\n\n",vet[0], vet[SIZE-1]);
	

	read_archive(vet, name_a);
	printf("antes: %d %d\n",vet[0],vet[SIZE-1]);
	start_time = clock();
	QuickSort(vet, 0, SIZE-1);
	end_time = clock();
	time_cost =(double)(end_time - start_time)/CLOCKS_PER_SEC;
	printf( "Execution time was %lfs\n",time_cost );
	printf("%d %d // Quick random: ok\n\n",vet[0], vet[SIZE-1]);

	read_archive(vet, name_a);
	printf("antes: %d %d\n",vet[0],vet[SIZE-1]);
	start_time = clock();
	select_sort(vet);
	end_time = clock();
	time_cost =(double)(end_time - start_time)/CLOCKS_PER_SEC;
	printf( "Execution time was %lfs\n",time_cost );
	printf("%d %d Select: ok\n\n",vet[0], vet[SIZE-1]);
	

	read_archive(vet, name_a);
	printf("antes: %d %d\n",vet[0],vet[SIZE-1]);
	start_time = clock();
	Sort(vet, 0, SIZE-1);
	end_time = clock();
	time_cost =(double)(end_time - start_time)/CLOCKS_PER_SEC;
	printf( "Execution time was %lfs\n",time_cost );
	printf("%d %d // Merge: ok\n\n",vet[0],vet[SIZE-1]);

	read_archive(vet, name_a);
	printf("antes: %d %d\n",vet[0],vet[SIZE-1]);
	start_time = clock();
	heap_sort(vet, SIZE);
	end_time = clock();
	time_cost =(double)(end_time - start_time)/CLOCKS_PER_SEC;
	printf( "Execution time was %lfs\n",time_cost );
	printf("%d %d // Heap: ok\n\n",vet[0],vet[SIZE-1]);
    
    
}


void read_archive(int *vet,char *name){

    int n;
    int i;
    FILE *arqv;
 
    //recebe nome de arquivo com valores desordenados
    // ex.: 1000-arq1.txt
    
    arqv = fopen(name,"r");

    if(arqv == NULL){
        printf("Fail, could not open file.\n");
    }

    i = 0;

    while( !feof(arqv) ){
        
        fscanf(arqv,"%d",&n);
        vet[i++] = n;
    }

    fclose(arqv);
	
   
}


void bubble_sort(int *vet){
    int i, j,aux;

    for(j = SIZE - 1; j >= 1; j--){

        for(i = 0; i < j; i++){
                
                if(vet[i] > vet[i+1]){

                    aux = vet[i];
                    vet[i] = vet[i+1];
                    vet[i+1] = aux;
                }
        }
        
    }
    
}

void QuickSort(int *vet,int begin,int end){

    int i,j,pivo,aux;
    i = begin;
    j = end;

    pivo = vet[( ( end + begin )/2 )];
    
    while ( i <= j){
        
        if (vet[i] < pivo){

            i++;
        } else if( vet[j] > pivo){
            j--;
        } else{
            aux = vet[i];
            vet[i] = vet[j];
            vet[j] = aux;
            i++;
            j--;
        }
    
    }
    if(j > begin){
        QuickSort(vet, begin, j);

    }
    if(i < end){
        QuickSort(vet,j+1,end);
    }
}
void QuickSort_rand(int *vet,int begin,int end){

    int i,j,pivo,aux;
    i = begin;
    j = end;

    pivo = vet[rand() % SIZE];
    
    while ( i <= j){
        
        if (vet[i] < pivo){

            i++;
        } else if( vet[j] > pivo){
            j--;
        } else{
            aux = vet[i];
            vet[i] = vet[j];
            vet[j] = aux;
            i++;
            j--;
        }
    
    }
    if(j > begin){
        QuickSort(vet, begin, j);

    }
    if(i < end){
        QuickSort(vet,j+1,end);
    }
}

void select_sort(int *vet){
	int i,j;
    int vetAux[SIZE],aux;
    int lowest_p;

	for (i = 0; i < SIZE-1; i++){
        
        lowest_p = i;
        
        for (j = i+1; j < SIZE; j++){
            
            if (vet[j] < vet[lowest_p]){
                
                lowest_p = j;

            
            }
        
        
        }
        
        aux = vet[i];
        vet[i] = vet[lowest_p];
        vet[lowest_p] = aux;
    }
    
}



// faz o merge e volta as galhas ordenando
void Merge(int *vet,int begin, int middle, int end){
        int *vetAux,size;
        int i,j,k;
        
        size = (end - begin) + 1;
        
        vetAux = (int*) malloc(sizeof(int) * size);
        // i com o inicio do subvetor a esquerda
        i = begin;
        // j com o inicio do subvetor a direita
        j = middle + 1;
        // tamanho do vetor inicial
        for(k = 0; k < size; k++){
            // verifica se os lados dos meus subvetores ainda tem valores a direita
            if(i < (middle+1) && j <= end){
                // faz a ordenacao crescente
                if(vet[i] < vet[j]){
                    
                    vetAux[k] = vet[i++];
                    
                }else{
                    
                    vetAux[k] = vet[j++];
                    
                }
                
            // se um dos subvetores chegou ao fim completa com o outro
            }else if(i < (middle+1) && j > end){
                
                vetAux[k] = vet[i++];
                
            }else{
                
                vetAux[k] = vet[j++];
                
            }
                
        }
        i = 0;
        for(k = begin; k <= end; k++){
            vet[k] = vetAux[i++];
            
        }
        free(vetAux);
            
}

void Sort(int *vet,int begin, int end){
    int middle;
    if( begin < end){
        middle = ( (begin + end)/ 2);
        // quebra pro lado esquerdo
        Sort(vet, begin, middle);
        // quebra pro lado direito
        Sort(vet, middle + 1, end);
        // faz o merge
        Merge(vet,begin, middle, end);
    }
    
}

void heap_sort(int *vet, int n){
	int i = n/2;
	int f,s,t;
	//f father , s son

	while(1) {
      if (i > 0) {
          i--;
          t = vet[i];
      } else {
          n--;
          if (n <= 0){ 
          	return;
          }
          t = vet[n];
          vet[n] = vet[0];
      }
      f = i;
      s = i * 2 + 1;
      while (s < n) {
          if ( ( s + 1 < n )  &&  ( vet[s + 1] > vet[s] ) ){
              s++;
          }
          if (vet[s] > t) {
             vet[f] = vet[s];
             f = s;
             s = f * 2 + 1;
          } else {
             break;
          }
      }
      vet[f] = t;
   }
}
