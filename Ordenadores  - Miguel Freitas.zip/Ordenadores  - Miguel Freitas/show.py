

import matplotlib.pyplot as plt
import numpy as np

qtd	= ["10","100","1000","10000","100000","10000000"]
tempo_b = [0.000002,0.000043, 0.002713, 0.298421, 36.541577, 3680.609191]
tempo_qf = [0.000002, 0.000011, 0.000111, 0.001339, 0.016167, 0.189550]
tempo_qr = [0.000002,0.000009,0.000107, 0.001349, 0.015721, 0.189608 ]
tempo_s = [0.000001, 0.000024, 0.001382, 0.128753, 14.528973, 1284.500553]
tempo_m = [0.000004, 0.000021, 0.000172, 0.001981, 0.024696, 0.288642]
tempo_h = [0.000002, 0.000012, 0.000141, 0.001788, 0.022909, 0.330584]

ordenadores = ['Bubble','Insertion','Quick F','Quick A','Merge','Heap']

plt.plot(qtd[4:], tempo_b[4:],color='green', label='Bubble')
plt.plot(qtd[4:], tempo_s[4:],'bar',color='orange', label='Select')

plt.plot(qtd[4:], tempo_qf[4:],'bar', color='red', label='Quick F.')
plt.plot(qtd[4:], tempo_qr[4:],'bar',color='blue', label='Quick R')

plt.plot(qtd[4:], tempo_m[4:],'bar', color='yellow', label='Merge')
plt.plot(qtd[4:], tempo_h[4:],'bar', color='purple', label='Heap')

plt.title("Tempo P/ Ordenacao")

plt.grid()
plt.legend(loc=9)

plt.ylabel("Tempo (segundos)")
plt.xlabel("Qtd. valores")
#plt.savefig("Pequenos valores")
plt.show()
