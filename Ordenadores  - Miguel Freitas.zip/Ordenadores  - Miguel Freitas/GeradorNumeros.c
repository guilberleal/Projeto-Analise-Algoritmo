/*
 * Estrutura de Dados 1
 * Professor Ivairton
 * 
 * Trabalho 5 - Metodos de ordenação(ETAPA 1) ( 27 nov 2017)
 */

#include <stdio.h>
#include <stdlib.h>// necessário p/ as funções rand() e srand()
#include <time.h>//necessário p/ função time()
#include <string.h>
//MAX receberá a quantidade de valores a serem gerados

int MAX = 10;

void move_right(char *name,int pos);

int main()
{
    int i,k;
    char nameArq[50];
    FILE *arqv;
    int controle;
    strcpy(nameArq,"");
    //nome do arquivo de saida com numeros aleatorios que nao se repetem
    
    int pos = 2;
    strcpy(nameArq,"10-arq.txt");
    
    
    
    srand(time(NULL));
    
    for(int l = 0 ; l < 10; l++){
        printf("name: %s\n",nameArq);
        arqv = fopen(nameArq,"w");
        srand(time(NULL));
        if(arqv == NULL){
            printf("Erro na abertura do arquivo.\n");
        }        
        for(i=0; i < MAX; i++){
            
            controle = (1+rand() % 999999);
            if(controle != 0){
                fprintf(arqv,"%d\n", controle);
            } else {
                i--;
            }
        }
        
        move_right(nameArq, pos);
        nameArq[pos++] = '0';
        MAX = MAX * 10;
        fclose(arqv);
        arqv = NULL;    
    }
    
     return 0;
}


void move_right(char *name,int pos){
    int t = strlen(name);
    for(int i = t; i >= pos; i--){
        name[i] = name[i-1];
    }
    name[t+1] = '\0';
}